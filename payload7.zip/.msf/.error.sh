cd
cd metasploit-framework
bundle update nokogiri


