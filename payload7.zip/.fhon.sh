echo -e "                        📟      "
echo -e "    📟                          "
echo -e "                                "
echo -e "                                "
echo -e "                                "
echo -e "               📩               "
echo -e "                                "
echo -e "                                "
echo -e "    📟                          "
echo -e "                            📱  "
sleep 0.2
clear



echo -e "                        📟      "
echo -e "    📟                 +        "
echo -e "      +                         "
echo -e "                                "
echo -e "                                "
echo -e "               📩               "
echo -e "                                "
echo -e "      +                         "
echo -e "    📟                          "
echo -e "                            📱  "
sleep 0.2
clear





echo -e "                        📟      "
echo -e "    📟                          "
echo -e "                      +         "
echo -e "        +                       "
echo -e "                                "
echo -e "               📩               "
echo -e "       +                        "
echo -e "                                "
echo -e "    📟                          "
echo -e "                            📱  "
sleep 0.2
clear


echo -e "                        📟      "
echo -e "    📟                          "
echo -e "                                "
echo -e "                     +          "
echo -e "         +                      "
echo -e "               📩               "
echo -e "         +                      "
echo -e "                                "
echo -e "    📟                          "
echo -e "                            📱  "
sleep 0.2
clear



echo -e "                        📟      "
echo -e "    📟                          "
echo -e "                                "
echo -e "                                "
echo -e "                   +            "
echo -e "           +   📩               "
echo -e "            +                   "
echo -e "                                "
echo -e "    📟                          "
echo -e "                            📱  "
sleep 0.2
clear



echo -e "                        📟      "
echo -e "    📟                          "
echo -e "                                "
echo -e "                                "
echo -e "                                "
echo -e "             +📩+               "
echo -e "              +                 "
echo -e "                                "
echo -e "    📟                          "
echo -e "                            📱  "
sleep 0.2
clear




echo -e "                        📟      "
echo -e "    📟                          "
echo -e "                                "
echo -e "                                "
echo -e "                                "
echo -e "             +📩+               "
echo -e "              + \               "
echo -e "                                "
echo -e "    📟                          "
echo -e "                            📱  "
sleep 0.2
clear


echo -e "                        📟      "
echo -e "    📟                          "
echo -e "                                "
echo -e "                                "
echo -e "                                "
echo -e "             +📩+               "
echo -e "              + \_________      "
echo -e "                                "
echo -e "    📟                          "
echo -e "                            📱  "
sleep 0.2
clear


echo -e "                        📟      "
echo -e "    📟                          "
echo -e "                                "
echo -e "                                "
echo -e "                                "
echo -e "             +📩+               "
echo -e "              + \_________      "
echo -e "                          \     "
echo -e "    📟                     \    "
echo -e "                            📱  "
sleep 0.2
clear
