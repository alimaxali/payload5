# Spammer-Grab
Spams GAC (Grab Activation Code) SMS to a phone number repeatedly per 60 second. "Spammer" uses Grab passenger API to make the GAC sms sent. "Spammer" is tested under Python 2.7

# Installation ( For Debian and Ubuntu )
1. `sudo apt install git` - To install git
2. `git clone https://github.com/Noxturnix/Spammer-Grab` - To clone a FIXED version
3. `cd Spammer-Grab` - To enter the directory of this git
4. `./auto-install.sh` - To install all required packages and python modules

# How to use?
Just type `python2 spammer.py -h` to show the help message.

# Me
E-Mail:
p4kl0nc4t@obsidiancyberteam.id (owner)
admin@noxt.cf (fixer)
Do not hesitate to contact us :)
