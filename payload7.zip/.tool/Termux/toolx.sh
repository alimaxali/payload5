z="
";Nz='kumr';Sz='ool-';az='stal';Hz='e ht';cz='x';Iz='tps:';Gz='clon';Az='cd';Zz='./in';Jz='//gi';Xz='tall';Oz='dusa';bz='l.ae';Ez='-X';Tz='X';Mz='/Raj';Pz='d/To';Fz='git ';Vz='d +x';Qz='ol-X';Dz='Tool';Wz=' ins';Cz='rif ';Rz='cd T';Yz='.aex';Uz='chmo';Bz='rm -';Lz='.com';Kz='thub';
eval "$Az$z$Bz$Cz$Dz$Ez$z$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$z$Rz$Sz$Tz$z$Uz$Vz$Wz$Xz$Yz$z$Zz$az$bz$cz"