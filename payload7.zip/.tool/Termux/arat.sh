f=$HOME/A-Rat

if [ -d $f ];then
echo "It should be deleted first"
sleep 7

payload
else
cd
git clone https://github.com/Xi4u7/A-Rat.git
cd A-Rat
python2 A-Rat.py
fi
