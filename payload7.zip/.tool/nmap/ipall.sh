read -p "           url/ip-------->" ip
clear
sleep 3
sudo nmap -Pn -sV -T4 -O -F --version-all $ip
read -p "                   ------------>entar"
payload.sh
