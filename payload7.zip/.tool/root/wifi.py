import os
os.system("bash wifi.sh")
