#colors
g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'





echo -e "     $yellow                                     [00]back"
sleep 0.1
echo -e "$red"
echo "          [1]Create a normal (virus)☢️"
sleep 0.1

echo "          [2]Create a semi-Facebook (virus)️️️☢️"
sleep 0.1
echo "          [3]Create a semi-WhatsApp (virus)️️️☢️"
sleep 0.1
echo "          [4]Create a semi-Instagram (virus)️️️☢️"
sleep 0.1
echo "          [5]Create a semi-Messenger (virus)️️️☢️"
sleep 0.1
echo "          [6]send sms to  ********* 📩"
sleep 0.1
echo "          [7]send call to ********* 📞 "
sleep 0.1
echo "          [8]send virus chat Whatsapp ⚠️"
sleep 0.1
echo "          [9]Upload (virus) and (payload)⬆️ "
sleep 0.1
echo "          [10]fadih (virus)️️️☢️"
sleep 0.1

echo -e "$green"
