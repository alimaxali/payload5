echo "                                       [0]back"
read -p "         [port]- - - > " port
if [ "$port" -eq "0"  ]; then
payload.sh
else
cd && ./ngrok tcp $port
fi
