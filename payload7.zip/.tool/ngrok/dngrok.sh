#colors
g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'                                                       
green='\033[1;32m'
red='\033[1;31m'                                                        
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'

echo -e "$yellow"
echo "                           open the http://www.ngrok.com"
echo "                   The link starts (./ngrok)"
echo ""
echo "                           [0] back"
termux-open http://www.ngrok.com
read -p "link- - - - > " link
if [ "$link" -eq "0"  ]; then
payload.sh
else
echo -e "$green"
cp $HOME/payload5/.ngrok/ngrok $HOME
cd $HOME && chmod 777 ngrok
$link
payload
echo -e "$yellow"
echo "                                   good pay"

fi
